ROMANTIC LOVE LETTER WEBSITE — BEGINNER GUIDE

WHAT'S INCLUDED
- index.html: the complete website (HTML, CSS, and JavaScript)
- assets/: put your photos and music in this folder

PERSONALIZE IT
1. Open index.html in Notepad or a code editor.
2. Replace "For You, My Love" and edit the letter text.
3. Replace "Your person ❤️" with your name or nickname.
4. Put three photos in assets/ named exactly:
   photo1.jpg
   photo2.jpg
   photo3.jpg
   JPG or PNG files are fine if you also update each image filename in index.html.
5. Put an audio file you are allowed to share in assets/ named:
   our-song.mp3
   Use music you own or have permission to share. If you do not want music, you can remove the audio element and music button.

TEST IT
- Double-click index.html to open it in Chrome or Edge.
- Click "Play our song"; browsers generally block music autoplay until a visitor interacts with the page.

PUBLISH IT AS A LINK (NETLIFY)
1. Keep index.html and the assets folder together inside this project folder.
2. Sign in or create an account at https://app.netlify.com/drop
3. Drag the whole project folder (or a ZIP of its contents) into the drop area, following the site's current prompts.
4. Wait for the deployment to finish and copy the generated website URL.
5. Open that URL in a private/incognito window or on your phone to test it.
6. Share the URL with the person you made it for.

IMPORTANT
- Do not include private information you would not want publicly accessible.
- Anyone with the public link may be able to view the letter and photos.
- Test the published link before sending it.
